# Style Story — audited cart/checkout build

## Important: preserve your store data
This ZIP intentionally does not include `data/products.json` or `data/orders.json`, so it will not overwrite your store's products or orders when extracted over an existing project. The server creates empty JSON files only if they do not exist. Keep a backup of `data/products.json`, `data/orders.json`, `.env`, and `public/uploads` before replacing files. If installing in a new folder, copy those files/folders from your existing project before starting.

## Run
1. Stop the currently running server with Ctrl+C in the terminal where it was started.
2. Open a terminal in THIS extracted folder.
3. Run `npm install` once, then `npm start`.
4. Confirm the terminal says the server is listening on port 3000. If port 3000 is already in use, stop the old server first rather than testing the old version by accident.
5. Open `http://localhost:3000` and hard-refresh with Ctrl+Shift+R.

## Included checks/fixes
- Product IDs are normalized from `id`, `productId`, `product_id`, or `sku`; missing IDs are assigned once and persisted.
- Checkout accepts those same ID keys and returns a clearer message for a stale cart item.
- Cart badge counts quantities (one item + another item = 2; same product quantity 2 = 2).
- Legacy cart records are normalized; stale items stay visible so the customer can remove them rather than silently disappearing.
- Phone and PIN code server-side validation remains enabled.
- Product details, Track Order, UPI pending/verified confirmation and Copy Order ID remain included.

## Payment note
UPI payment is not automatically verified. The store owner must confirm the payment in the bank/UPI app and update the order status in admin.
